# GlowUp Tracker — iPhone installable web app

## What is included
- Food logging with photo attachment and macro fields
- Daily calorie, protein, carb and fat totals
- Custom habits and daily check-offs
- Editable calorie/protein goals
- Reminder time preferences
- Local browser storage and JSON export

## Important limitations
This is a working installable web-app prototype, not an App Store-native app. Meal photos and data stay in the browser storage on the device; there is no account/cloud sync. Photo-based macro recognition is not built into this version: add the photo, then enter a label-based or ChatGPT-estimated macro value. The reminder setting is saved, but this version only triggers an in-app alert while the app is open. Real iOS background notifications need a push service and server-side setup.

## Put it online for iPhone installation
A Progressive Web App must be served from HTTPS to install reliably on iPhone.

1. Create a free GitHub account if you do not have one.
2. Create a new public repository named `glowup-tracker`.
3. Upload `index.html`, `manifest.json`, and `sw.js` from this folder to the repository root.
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. Open the published HTTPS address in Safari on your iPhone.
7. Tap **Share → Add to Home Screen → Add**.

After installation, launch GlowUp from your home screen. Keep the original published website available so the app can update.

## Privacy
Data is stored locally in the browser using localStorage. Avoid logging highly sensitive information. Export your data periodically if you want a backup.
